#!/usr/bin/env python3
"""
Soccer prediction model using Poisson distribution.
Same logic applies to hockey and handball with different league averages.
"""
import math
from scipy.special import factorial

HOME_ADV = 1.12
LEAGUE_AVG_GOALS = 2.67  # Global soccer average ~2.67 goals per game
MAX_GOALS = 6


def poisson_pmf(k, lam):
    """Poisson probability mass function."""
    return math.exp(-lam) * (lam ** k) / math.factorial(k)


def calculate_probabilities(
    home_attack, away_attack,
    home_defence, away_defence,
    rest_factor=1.0,
    league_avg=LEAGUE_AVG_GOALS
):
    """
    Calculate match outcome probabilities using Poisson model.

    λ_home = home_attack * away_defence * league_avg_goals * HOME_ADV * rest_factor
    λ_away = away_attack * home_defence * league_avg_goals * rest_factor
    """
    lam_home = home_attack * away_defence * league_avg * HOME_ADV * rest_factor
    lam_away = away_attack * home_defence * league_avg * rest_factor

    # Precompute PMF values for k=0 to 6
    p_home = [poisson_pmf(k, lam_home) for k in range(MAX_GOALS + 1)]
    p_away = [poisson_pmf(k, lam_away) for k in range(MAX_GOALS + 1)]

    # P(home win) = sum_{i=1 to 6} sum_{j=0 to i-1} P(i;λ_home) * P(j;λ_away)
    p_home_win = 0.0
    for i in range(1, MAX_GOALS + 1):
        for j in range(0, i):
            p_home_win += p_home[i] * p_away[j]

    # P(draw) = sum_{i=0 to 6} P(i;λ_home) * P(i;λ_away)
    p_draw = 0.0
    for i in range(MAX_GOALS + 1):
        p_draw += p_home[i] * p_away[i]

    # P(away win) = 1 - P_home_win - P_draw
    p_away_win = 1.0 - p_home_win - p_draw

    # P(over 2.5) = sum_{total > 2.5} P(i) * P(j)
    p_over_2_5 = 0.0
    for i in range(MAX_GOALS + 1):
        for j in range(MAX_GOALS + 1):
            if i + j > 2.5:
                p_over_2_5 += p_home[i] * p_away[j]

    return {
        "p_home": round(p_home_win, 4),
        "p_draw": round(p_draw, 4),
        "p_away": round(p_away_win, 4),
        "ou25_over": round(p_over_2_5, 4),
        "fair_odds_home": round(1.0 / p_home_win, 2) if p_home_win > 0 else 999,
        "fair_odds_draw": round(1.0 / p_draw, 2) if p_draw > 0 else 999,
        "fair_odds_away": round(1.0 / p_away_win, 2) if p_away_win > 0 else 999,
        "lambda_home": round(lam_home, 3),
        "lambda_away": round(lam_away, 3),
    }


def predict_match(home_team_stats, away_team_stats, league_avg=LEAGUE_AVG_GOALS):
    """
    Predict a single match given team stats.

    home_team_stats: dict with keys 'attack', 'defence', 'rest_factor'
    away_team_stats: dict with keys 'attack', 'defence', 'rest_factor'
    """
    home_attack = home_team_stats.get("attack", 1.0)
    home_defence = home_team_stats.get("defence", 1.0)
    away_attack = away_team_stats.get("attack", 1.0)
    away_defence = away_team_stats.get("defence", 1.0)
    rest_factor = home_team_stats.get("rest_factor", 1.0)

    return calculate_probabilities(
        home_attack, away_attack,
        home_defence, away_defence,
        rest_factor=rest_factor,
        league_avg=league_avg
    )


def extract_team_stats_from_api(fixture_data, team_stats_response):
    """
    Extract attack/defence ratings from API-SPORTS team statistics.
    Returns default values if data is unavailable.
    """
    if not team_stats_response:
        return {"attack": 1.0, "defence": 1.0, "rest_factor": 1.0}

    try:
        # API-SPORTS returns nested stats
        stats = team_stats_response
        if isinstance(stats, list) and len(stats) > 0:
            stats = stats[0]

        # Extract goals scored/conceded per game
        goals_for = stats.get("goals", {}).get("for", {}).get("average", {}).get("total", 1.34)
        goals_against = stats.get("goals", {}).get("against", {}).get("average", {}).get("total", 1.34)

        # Normalize to league average
        attack = float(goals_for) / (LEAGUE_AVG_GOALS / 2)
        defence = float(goals_against) / (LEAGUE_AVG_GOALS / 2)

        return {
            "attack": max(0.5, min(2.0, attack)),
            "defence": max(0.5, min(2.0, defence)),
            "rest_factor": 1.0,
        }
    except Exception as e:
        print(f"[WARN] Could not extract team stats: {e}")
        return {"attack": 1.0, "defence": 1.0, "rest_factor": 1.0}
