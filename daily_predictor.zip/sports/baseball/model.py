#!/usr/bin/env python3
"""
Baseball prediction model using Pythagorean expectation + Poisson.
"""
import math

PYTHAG_EXPONENT = 1.82
LEAGUE_AVG_RUNS = 4.5
MAX_GOALS = 6  # Reuse same matrix size


def poisson_pmf(k, lam):
    """Poisson probability mass function."""
    return math.exp(-lam) * (lam ** k) / math.factorial(k)


def pythagorean_win_pct(runs_scored, runs_allowed):
    """
    Bill James Pythagorean expectation.
    win_pct = RS^1.82 / (RS^1.82 + RA^1.82)
    """
    rs_exp = runs_scored ** PYTHAG_EXPONENT
    ra_exp = runs_allowed ** PYTHAG_EXPONENT
    return rs_exp / (rs_exp + ra_exp)


def calculate_probabilities(
    home_rs_per_game, home_ra_per_game,
    away_rs_per_game, away_ra_per_game,
    park_factor=1.0,
    league_avg=LEAGUE_AVG_RUNS,
    total_line=8.5
):
    """
    Calculate baseball match probabilities.

    λ_home = (home_RS_per_game * away_RA_per_game / league_avg) * park_factor
    λ_away = (away_RS_per_game * home_RA_per_game / league_avg) * park_factor
    """
    lam_home = (home_rs_per_game * away_ra_per_game / league_avg) * park_factor
    lam_away = (away_rs_per_game * home_ra_per_game / league_avg) * park_factor

    # Poisson matrix for moneyline (same as soccer)
    p_home = [poisson_pmf(k, lam_home) for k in range(MAX_GOALS + 1)]
    p_away = [poisson_pmf(k, lam_away) for k in range(MAX_GOALS + 1)]

    p_home_win = 0.0
    for i in range(1, MAX_GOALS + 1):
        for j in range(0, i):
            p_home_win += p_home[i] * p_away[j]

    p_draw = 0.0
    for i in range(MAX_GOALS + 1):
        p_draw += p_home[i] * p_away[i]

    p_away_win = 1.0 - p_home_win - p_draw

    # O/U runs
    p_over = 0.0
    for i in range(MAX_GOALS + 1):
        for j in range(MAX_GOALS + 1):
            if i + j > total_line:
                p_over += p_home[i] * p_away[j]

    # Pythagorean win probability as sanity check
    home_pyth = pythagorean_win_pct(home_rs_per_game, home_ra_per_game)
    away_pyth = pythagorean_win_pct(away_rs_per_game, away_ra_per_game)

    return {
        "p_home": round(p_home_win, 4),
        "p_draw": round(p_draw, 4),
        "p_away": round(p_away_win, 4),
        "ou_line": total_line,
        "ou_over": round(p_over, 4),
        "fair_odds_home": round(1.0 / p_home_win, 2) if p_home_win > 0 else 999,
        "fair_odds_away": round(1.0 / p_away_win, 2) if p_away_win > 0 else 999,
        "pythagorean_home": round(home_pyth, 4),
        "pythagorean_away": round(away_pyth, 4),
        "lambda_home": round(lam_home, 3),
        "lambda_away": round(lam_away, 3),
    }


def predict_match(home_team_stats, away_team_stats, park_factor=1.0, total_line=8.5):
    """
    Predict a single baseball match.

    home_team_stats: dict with keys 'rs_per_game', 'ra_per_game'
    away_team_stats: dict with keys 'rs_per_game', 'ra_per_game'
    """
    home_rs = home_team_stats.get("rs_per_game", 4.5)
    home_ra = home_team_stats.get("ra_per_game", 4.5)
    away_rs = away_team_stats.get("rs_per_game", 4.5)
    away_ra = away_team_stats.get("ra_per_game", 4.5)

    return calculate_probabilities(
        home_rs, home_ra,
        away_rs, away_ra,
        park_factor=park_factor,
        total_line=total_line
    )


def extract_team_stats_from_mlb(standings_data, team_id):
    """
    Extract runs scored/allowed per game from MLB standings data.
    """
    if not standings_data or "records" not in standings_data:
        return {"rs_per_game": 4.5, "ra_per_game": 4.5}

    try:
        for record in standings_data["records"]:
            for team_record in record.get("teamRecords", []):
                if str(team_record["team"]["id"]) == str(team_id):
                    runs_scored = team_record.get("runsScored", 0)
                    runs_allowed = team_record.get("runsAllowed", 0)
                    games = team_record.get("gamesPlayed", 1)

                    return {
                        "rs_per_game": runs_scored / max(1, games),
                        "ra_per_game": runs_allowed / max(1, games),
                    }
    except Exception as e:
        print(f"[WARN] Could not extract MLB team stats: {e}")

    return {"rs_per_game": 4.5, "ra_per_game": 4.5}
