#!/usr/bin/env python3
"""
Basketball prediction model using Normal distribution.
"""
from scipy.stats import norm

SIGMA_DIFF = 11.0
SIGMA_TOTAL = 14.0


def calculate_probabilities(
    home_off_rtg, away_off_rtg,
    pace,
    total_line=220.5
):
    """
    Calculate basketball match probabilities using Normal distribution.

    mu_home = pace * home_off_rtg / 100
    mu_away = pace * away_off_rtg / 100
    mu_diff = mu_home - mu_away + 2.5  # home court
    sigma_diff = 11.0

    P_home = Φ(mu_diff / sigma_diff)
    P_away = 1 - P_home

    Total points ~ N(mu_home + mu_away, sigma_total=14)
    P_over = 1 - Φ((line - mu_total) / sigma_total)
    """
    mu_home = pace * home_off_rtg / 100.0
    mu_away = pace * away_off_rtg / 100.0

    mu_diff = mu_home - mu_away + 2.5

    p_home = norm.cdf(mu_diff / SIGMA_DIFF)
    p_away = 1.0 - p_home

    mu_total = mu_home + mu_away
    p_over = 1.0 - norm.cdf((total_line - mu_total) / SIGMA_TOTAL)

    return {
        "p_home": round(p_home, 4),
        "p_away": round(p_away, 4),
        "ou_line": total_line,
        "ou_over": round(p_over, 4),
        "fair_odds_home": round(1.0 / p_home, 2) if p_home > 0 else 999,
        "fair_odds_away": round(1.0 / p_away, 2) if p_away > 0 else 999,
        "mu_home": round(mu_home, 2),
        "mu_away": round(mu_away, 2),
        "mu_total": round(mu_total, 2),
    }


def predict_match(home_team_stats, away_team_stats, total_line=220.5):
    """
    Predict a single basketball match.

    home_team_stats: dict with keys 'off_rtg', 'pace'
    away_team_stats: dict with keys 'off_rtg', 'pace'
    """
    home_off_rtg = home_team_stats.get("off_rtg", 110.0)
    away_off_rtg = away_team_stats.get("off_rtg", 110.0)

    # Use average pace
    pace_home = home_team_stats.get("pace", 100.0)
    pace_away = away_team_stats.get("pace", 100.0)
    pace = (pace_home + pace_away) / 2.0

    return calculate_probabilities(
        home_off_rtg, away_off_rtg,
        pace,
        total_line=total_line
    )


def extract_team_stats_from_api(fixture_data, team_stats_response):
    """
    Extract offensive rating and pace from API-SPORTS team statistics.
    """
    if not team_stats_response:
        return {"off_rtg": 110.0, "pace": 100.0}

    try:
        stats = team_stats_response
        if isinstance(stats, list) and len(stats) > 0:
            stats = stats[0]

        # Points per game as proxy for offensive rating
        ppg = stats.get("points", {}).get("for", {}).get("average", {}).get("total", 110.0)

        # Use points as offensive rating proxy
        off_rtg = float(ppg) * 100.0 / 100.0  # normalized

        # Estimate pace from games played
        games = stats.get("games", {}).get("played", {}).get("all", 1)
        pace = 100.0  # default league average pace

        return {
            "off_rtg": max(90.0, min(130.0, off_rtg)),
            "pace": max(90.0, min(110.0, pace)),
        }
    except Exception as e:
        print(f"[WARN] Could not extract basketball team stats: {e}")
        return {"off_rtg": 110.0, "pace": 100.0}
